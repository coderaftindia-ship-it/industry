 

<?php $__env->startSection('content'); ?>

<?php if($ps->slider == 1): ?>

<?php if(count($sliders)): ?>

<?php echo $__env->make('includes.slider-style', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php endif; ?>

<?php endif; ?>


	<?php if($ps->slider == 1): ?>

	<!-- Hero Area Start -->
	<section class="hero-area">
		<?php if(count($sliders)): ?>
			<div class="hero-area-slider">
					<?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="intro-content <?php echo e($data->position); ?>" style="background-image: url(<?php echo e(asset('assets/images/sliders/'.$data->photo)); ?>)">
							<div class="container">
								<div class="row">
									<div class="col-lg-12">
										<div class="slider-content">
											<!-- layer 1 -->
											<div class="layer-1">
												<h4 style="font-size: <?php echo e($data->subtitle_size); ?>px; color: <?php echo e($data->subtitle_color); ?>" class="subtitle subtitle<?php echo e($data->id); ?>" data-animation="animated <?php echo e($data->subtitle_anime); ?>"><?php echo e($data->subtitle_text); ?></h4>
												<h2 style="font-size: <?php echo e($data->title_size); ?>px; color: <?php echo e($data->title_color); ?>" class="title title<?php echo e($data->id); ?>" data-animation="animated <?php echo e($data->title_anime); ?>"><?php echo e($data->title_text); ?></h2>
											</div>
											<!-- layer 2 -->
											<div class="layer-2">
												<p style="font-size: <?php echo e($data->details_size); ?>px; color: <?php echo e($data->details_color); ?>"  class="text text<?php echo e($data->id); ?>" data-animation="animated <?php echo e($data->details_anime); ?>"><?php echo e($data->details_text); ?></p>
											</div>
											<!-- layer 3 -->
											<div class="layer-3">
												<a href="<?php echo e($data->link); ?>" target="_blank" class="mybtn1"><span><?php echo e($langg->lang8); ?> <i class="fas fa-chevron-right"></i></span></a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		<?php endif; ?>
	</section>
	<!-- Hero Area End -->

	<?php endif; ?>

	<?php if($ps->service == 1): ?>

	<!-- Features Area Start-->
	<section class="features">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="feature-area">
						<div class="row">
							<?php $__currentLoopData = DB::table('services')->where('is_featured',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
							<div class="col-lg-4 col-md-6">
								<a href="<?php echo e(route('front.service',$service->slug)); ?>" target="_blank" class="single-feature">
									<div class="icon">
										<img src="<?php echo e(asset('assets/images/services/'.$service->photo)); ?>" alt="">
									</div>
									<div class="content">
										<h4 class="title">
											<?php echo e($service->title); ?>

										</h4>
										<p class="text">
											<?php echo e($service->subtitle); ?>

										</p>
										<span class="link">
											<i class="fas fa-angle-double-right"></i>
										</span>
									</div>
								</a>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Features Area End-->

	<?php endif; ?>

	<?php if($ps->featured == 1): ?>

	<!-- About Area Start-->
	<section class="about">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="about-img">
						<img src="<?php echo e(asset('assets/images/'.$gs->service_image)); ?>" alt="">
					</div>
				</div>
				<div class="col-lg-6 d-flex align-self-center">
					<div class="about-content">
							<div class="section-heading">
									<h5 class="sub-title">
											<?php echo $gs->service_subtitle; ?>

									</h5>
									<h2 class="title extra-padding">
										<?php echo $gs->service_title; ?>

									</h2>
								</div>
								<div class="content">
									<?php echo $gs->service_text; ?>

									<?php if($gs->service_link != null): ?>
									<a href="<?php echo e($gs->service_link); ?>" class="mybtn1" ><?php echo e($langg->lang9); ?></a>
									<?php endif; ?>
								</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Features Area End-->

	<?php endif; ?>

	<?php if($ps->small_banner == 1): ?>

	<!-- Statistic Area Start -->
	<section class="statistic" style="background: url(<?php echo e(asset('assets/images/'.$ps->video_background)); ?>);">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="section-heading color-white text-left">
						<h5 class="sub-title">
							<?php echo e($ps->video_subtitle); ?>

						</h5>
						<h2 class="title">
							<?php echo e($ps->video_title); ?>

						</h2>
						<p class="text">
							<?php echo e($ps->video_text); ?>

						</p>
						<?php if($ps->video_link != null): ?>
						<a href="javascript:;"  data-toggle="modal" data-target="#user-login" class="mybtn1">
							<?php echo e($langg->lang56); ?>

						</a>
						<?php endif; ?>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="col-lg-12">
						<div class="row">
							<?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-md-6">
								<div class="single-statistic">
									<div class="icon">
										<img src="<?php echo e(asset('assets/images/experience/'.$data->photo)); ?>" alt="">
									</div>
									<p class="text">
										<?php echo e($data->title); ?>

									</p>
								</div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>							
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Statistic Area End -->

	<?php endif; ?>

	<?php if($ps->best == 1): ?>

	<!-- Service Area Start -->
	<section class="service">
		<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-8 col-md-10">
				<div class="section-heading">
					<h5 class="sub-title">
							<?php echo e($ps->service_subtitle); ?>

					</h5>
					<h2 class="title">
							<?php echo e($ps->service_title); ?>

					</h2>
					<p class="text">
							<?php echo e($ps->service_text); ?>  
					</p>
				</div>
			</div>
		</div>
		</div>
		<div class="container">
			<div class="row">
				<?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-lg-4 col-md-6">
					<div class="single-service">
						<div class="icon">
							<img src="<?php echo e(asset('assets/images/features/'.$data->photo)); ?>" alt="">
						</div>
						<div class="content">
							<h4 class="title">
								<?php echo e($data->title); ?>

							</h4>
							<p>
								<?php echo $data->details; ?>

							</p>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</section>
	<!-- Service Area End -->

	<?php endif; ?>

	<?php if($ps->contact_section == 1): ?>

	<!-- Submit Address Area Start -->
<div class="submit-address"  style="background: url(<?php echo e(asset('assets/images/'.$ps->c_background)); ?>);">
		<div class="container">
			<div class="row">
				<div class="col-lg-7 col-md-7">
					<h4 class="title">
						<?php echo e($ps->c_title); ?>

					</h4>
				</div>
				<div class="col-lg-5 col-md-5 d-flex align-self-center j-end">
					<a href="<?php echo e(route('front.contact')); ?>" class="mybtn1"><?php echo e($langg->lang54); ?></a>
				</div>
			</div>
		</div>
	</div>
	<!-- Submit Address Area End -->

	<?php endif; ?>

	<?php if($ps->pricing_plan == 1): ?>

	<!-- Pricing Plan Area Start -->
<section class="pricing">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-7 col-md-10">
					<div class="section-heading">
						<h5 class="sub-title">
							<?php echo e($gs->price_subtitle); ?>

						</h5>
						<h2 class="title">
							<?php echo e($gs->price_title); ?>

						</h2>
						<p class="text">
							<?php echo e($gs->price_text); ?>

						</p>
					</div>
				</div>
			</div>

<?php 

$is_second = false;

?>

<?php $__currentLoopData = $products->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<div class="row <?php echo e($is_second ? 'pt-3' : ''); ?>">

			<?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<div class="col-lg-4">
					<div class="single-plan">
						<div class="header">
							<h4 class="title">
								<?php echo e($prod->title); ?>

							</h4>
							<p class="sub-title">
								<?php echo e($prod->subtitle); ?>

							</p>
						</div>
						<div class="price">
							<p class="num">
								<?php echo $prod->showPrice(); ?>

							</p>
							<span class="time">/ <?php echo e($prod->type); ?></span>
						</div>
						<div class="content-text">
							<?php echo $prod->details; ?>

						</div>
						<a href="<?php echo e(route('front.checkout',$prod->slug)); ?>" class="mybtn1">
							<?php echo e($langg->lang10); ?>

						</a>
					</div>
				</div>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php 

$is_second = true;

?>

			</div>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


		</div>

	</section>
	<!-- Pricing Plan Area End -->

	<?php endif; ?>

	<?php if($ps->top_rated == 1): ?>

	<!-- Package Gallery Area Start -->
	<section class="gallery"> 
			<div class="container">
					<div class="row justify-content-center">
						<div class="col-lg-7 col-md-10">
							<div class="section-heading">
								<h5 class="sub-title">
										<?php echo e($ps->portfolio_subtitle); ?>

								</h5>
								<h2 class="title">
										<?php echo e($ps->portfolio_title); ?>

								</h2>
								<p class="text">
										<?php echo e($ps->portfolio_text); ?> 
								</p>
							</div>
						</div>
					</div>
				<div class="row">
					<div class="col-lg-12">
						<div class="gallery-slider">
							<?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="item">
									<a href="<?php echo e(route('front.project',$data->slug)); ?>" class="single-project">
										<div class="img">
												<img src="<?php echo e(asset('assets/images/portfolio/'.$data->photo)); ?>" alt="">
										</div>
										<div class="content">
											<p class="sub-title">
													<?php echo e($data->title); ?>

											</p>
											<h4 class="title">
													<?php echo e($data->subtitle); ?>

											</h4>
											<span class="link">
													<i class="fas fa-angle-double-right"></i>
												</span>
										</div>
									</a>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- Package Gallery Area End -->

		<?php endif; ?>

	<?php if($ps->large_banner == 1): ?>

		<!-- Video Area Start -->
		<section class="video-section" style="background: url(<?php echo e(asset('assets/images/'.$ps->p_background)); ?>);">
			<div class="container">
				<div class="row justify-content-between">
					<div class="col-lg-6 align-self-center">
						<div class="section-heading color-white text-left ">
							<h2 class="title">
								<?php echo e($ps->p_subtitle); ?>

							</h2>
							<p class="text"><?php echo e($ps->p_title); ?></p>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="video-box">
							<img src="<?php echo e(asset('assets/images/'.$ps->video_image)); ?>" alt="">
							<div class="play-icon">
								<a href="<?php echo e($ps->p_text); ?>" class="video-play-btn mfp-iframe">
									<i class="fas fa-play"></i>
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- Video Area End -->

		<?php endif; ?>

	<?php if($ps->big == 1): ?>

		<!-- Team Area Start -->
			<section class="team">
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-lg-7 col-md-10">
							<div class="section-heading">
								<h5 class="sub-title">
									<?php echo e($ps->team_subtitle); ?>

								</h5>
								<h2 class="title">
									<?php echo e($ps->team_title); ?>

								</h2>
								<p class="text">
									<?php echo e($ps->team_text); ?> 
								</p>
							</div>
						</div>
					</div>
					<div class="row">

				<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-lg-3 col-md-6">
					<div class="single-team">
						<div class="img">
							<img src="<?php echo e(asset('assets/images/member/'.$data->photo)); ?>" alt="">
						</div>
						<div class="content">
							<h4 class="title">
								<?php echo e($data->title); ?>

							</h4>
							<p class="designation">
								<?php echo e($data->subtitle); ?>

							</p>
							<ul class="social-links">
								<?php if($data->facebook != null): ?>
								<li>
									<a href="<?php echo e($data->facebook); ?>">
										<i class="fab fa-facebook-f"></i>
									</a>
								</li>
								<?php endif; ?>
								<?php if($data->twitter != null): ?>
								<li>
									<a href="<?php echo e($data->twitter); ?>">
										<i class="fab fa-twitter"></i>
									</a>
								</li>
								<?php endif; ?>
								<?php if($data->linkedin != null): ?>
								<li>
									<a href="<?php echo e($data->linkedin); ?>">
										<i class="fab fa-linkedin-in"></i>
									</a>
								</li>
								<?php endif; ?>
							</ul>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</div>
				</div>
			</section>
		<!-- Team Area End -->

		<?php endif; ?>

	<?php if($ps->hot_sale == 1): ?>

	<!-- Testimonial Area Start -->
	<section class="testimonial" style="background: url(<?php echo e(asset('assets/images/'.$ps->review_background)); ?>);">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-7 col-md-10">
					<div class="section-heading color-white">
						<h5 class="sub-title">
							<?php echo e($ps->review_subtitle); ?>

						</h5>
						<h2 class="title">
							<?php echo e($ps->review_title); ?>

						</h2>
						<p class="text">
							<?php echo e($ps->review_text); ?>

						</p>
					</div>
				</div>
			</div>
			<div class="row justify-content-center">
				<div class="col-lg-12">
					<div class="testimonial-slider">

					<?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<div class="single-testimonial">
							<div class="review-text">
								<p><?php echo e($review->details); ?></p>
							</div>
							<div class="people">
								<div class="img">
										<img src="<?php echo e(asset('assets/images/reviews/'.$review->photo)); ?>" alt="">
								</div>
								<div class="content">
									<h4 class="title"><?php echo e($review->title); ?></h4>
									<p class="designation"><?php echo e($review->subtitle); ?></p>
								</div>
							</div>
					</div>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Testimonial Area End -->

	<?php endif; ?>

	<?php if($ps->review_blog == 1): ?>

	<!-- Blog Area Start -->
	<section class="blog">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-7 col-md-10">
					<div class="section-heading">
						<h5 class="sub-title">
							<?php echo e($ps->blog_subtitle); ?>

						</h5>
						<h2 class="title">
							<?php echo e($ps->blog_title); ?>

						</h2>
						<p class="text">
							<?php echo e($ps->blog_text); ?> 
						</p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<div class="blog-slider">

					<?php $__currentLoopData = $lblogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<a href="<?php echo e(route('front.blogshow',$blogg->slug)); ?>" class="single-blog">
						<div class="img">
							<img src="<?php echo e(asset('assets/images/blogs/'.$blogg->photo)); ?>" alt="">
						</div>
						<div class="content">
							<h4 class="title">
								<?php echo e($blogg->title); ?>

							</h4>
							<ul class="top-meta">
								<li>
									<span>
											<i class="far fa-calendar"></i> <?php echo e(date('d M, Y',strtotime($blogg->created_at))); ?>

									</span>
								</li>
								<li>
									<span>
											<i class="far fa-eye"></i> <?php echo e($blogg->views); ?>

									</span>
								</li>
							</ul>
							<div class="text">
								<p>
									<?php echo e(substr(strip_tags($blogg->details),0,120)); ?>

								</p>
							</div>
							<span class="link"><?php echo e($langg->lang55); ?> <i class="fas fa-chevron-right"></i></span>
						</div>
					</a>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Blog Area End -->

	<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>