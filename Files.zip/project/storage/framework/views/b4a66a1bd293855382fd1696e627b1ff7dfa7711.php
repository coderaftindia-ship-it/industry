<?php $__env->startSection('content'); ?>

  <!-- Breadcrumb Area Start -->
  <div class="breadcrumb-area" style="background: url(<?php echo e($gs->breadcumb_banner ? asset('assets/images/'.$gs->breadcumb_banner):asset('assets/images/noimage.png')); ?>);">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <h1 class="pagetitle">
            <?php echo e($langg->lang47); ?>

          </h1>

          <ul class="pages">
                
              <li>
                <a href="<?php echo e(route('front.index')); ?>">
                  <?php echo e($langg->lang2); ?>

                </a>
              </li>
              <li>
                <a href="javascript:;">
                  <?php echo e($langg->lang47); ?>

                </a>
              </li>

          </ul>
        </div>
      </div>
    </div>
  </div>
  <!-- Breadcrumb Area End -->


<section class="fourzerofour">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="content">
            <img src="<?php echo e(asset('assets/front/images/404.png')); ?>" alt="">

              <?php echo $gs->error_title; ?>


              <?php echo $gs->error_text; ?>


            <a class="mybtn1 pt-3" href="<?php echo e(route('front.index')); ?>"><?php echo e($langg->lang48); ?></a>
          </div>
        </div>
      </div>
    </div>
  </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>